#include<stdio.h>
#include<time.h>

int main(){
	int win = 0;
	printf("WELCOME TO \% FORMAT STRING \%  VULNERABILITY \n");
	printf("Info Leak %p\n",&win);
	char message[100];
	printf("Give Me some message and I will repeat it\n");
	scanf("%100s",message);
	printf(message); //wooooooooooops
	if(win){
		printf("And we have a winner At %d",time(0));
		return 0;
	}else{
		printf("Pathetic LOL jk!");
		return 0;
	}
	return 0;
}

	
